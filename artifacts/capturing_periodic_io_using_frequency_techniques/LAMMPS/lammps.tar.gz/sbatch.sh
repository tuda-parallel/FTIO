#!/bin/bash
#SBATCH -J lammps
##SBATCH --mail-type=END
#SBATCH -e %x.err
#SBATCH -o %x.out
#SBATCH -n 1536
#SBATCH --mem-per-cpu=3800   
#SBATCH -t 00:10:00

export LD_PRELOAD=./libtmio.so  
srun ./lmp_mpi -in in.flow.pois
